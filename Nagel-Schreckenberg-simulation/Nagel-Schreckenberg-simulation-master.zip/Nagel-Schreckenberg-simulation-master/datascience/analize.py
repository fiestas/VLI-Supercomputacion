class Analyze():
    def __init__(self, collect):
        self.output = collect.output
