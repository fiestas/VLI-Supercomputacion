# Nagel Schreckenberg simulation

Este repositorio es un fork de la simulacion basada en automata celulares usando el modelo Nagel Schreckenberg realizada por morethanoneanimal. A partir de dicha simulacion se piensa realizar la paralelizacion del codigo, la adicion de un paquete de analisis de datos y de prediccion.

Nuevas caracteristicas:

- Paquete Datascience: Se encarga de recolectar, preprocesar y predecir usando los valores de la salida de la simulacion.
