./gpu-4th | tee -a tmp.log
./gpu-6th | tee -a tmp.log
./gpu-8th | tee -a tmp.log
